function toggleMobileMenu() {
    const mobileLinks = document.getElementById("mobileLinks");
    mobileLinks.classList.toggle("active");
}